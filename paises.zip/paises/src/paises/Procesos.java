package paises;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JOptionPane;

public class Procesos {
	HashMap<String, ArrayList<String>> mapaPaises;
	ArrayList<String> listCiudades;

	public Procesos() {
		mapaPaises = new HashMap<String, ArrayList<String>>();
		menu();
	}

	private void menu() {
		int opcion;
		do {
			opcion = Integer.parseInt(JOptionPane.showInputDialog("1.registrar paises\n" + " 2. Registrar ciudades\n"
					+ " 3.Consultar Ciudades por Pais\n" + " 4.Consultar Ciudad\n" + " 5.Salir\n"));
			iniciar(opcion);
		} while (opcion != 5);

	}

	private void iniciar(int opcion) {
		switch (opcion) {
		case 1:
			ingresarPaises();
			break;
		case 2:
			if (!mapaPaises.isEmpty()) {
				ingresarCiudades();
			} else {
				JOptionPane.showMessageDialog(null, "debe llenar los datos. opcion :1");
			}
			break;
		case 3:
			if (!mapaPaises.isEmpty()) {
				consultarPorPaisCiudades();
			} else {
				JOptionPane.showMessageDialog(null, "debe llenar los datos. opcion :1");
			}
			break;
		case 4:
			if (!mapaPaises.isEmpty()) {
				consultarCiudad();

			} else {
				JOptionPane.showMessageDialog(null, "debe llenar los datos. opcion :1");
			}
			break;
		case 5:
			JOptionPane.showMessageDialog(null, "salio del programa");
			break;

		default:
			JOptionPane.showMessageDialog(null, "ingrese un numero valido");
			break;
		}
	}

	private void ingresarPaises() {
		String nuevoPais;
		String ingresar;

		do {

			nuevoPais = JOptionPane.showInputDialog("Ingrese un pais");
			ingresar = JOptionPane.showInputDialog("Quiere ingresar otro pais? s/n");
			mapaPaises.put(nuevoPais, null);

		} while (ingresar.equalsIgnoreCase("s"));
	}

	private void ingresarCiudades() {
		String pais = JOptionPane.showInputDialog("Ingrese el pais al que le desea ingresar ciudades");
		String ciudad;
		String seguir;

		if (mapaPaises.containsKey(pais)) {
			listCiudades = new ArrayList<String>();
			do {
				ciudad = JOptionPane.showInputDialog("Ingrese la ciudad");
				listCiudades.add(ciudad);

				seguir = JOptionPane.showInputDialog("Quiere ingresar otra ciudad? s/n");

			} while (seguir.equalsIgnoreCase("s"));

			mapaPaises.put(pais, listCiudades);

		} else {
			JOptionPane.showMessageDialog(null, "No existe");
		}
	}

	private void consultarPorPaisCiudades() {
		String pais = JOptionPane.showInputDialog("Ingrese el pais para buscar sus ciudades");

		if (mapaPaises.containsKey(pais)) {
			JOptionPane.showMessageDialog(null, mapaPaises.get(pais));
		}
	}

	private void consultarCiudad() {

		String ciudad = JOptionPane.showInputDialog("Ingrese la ciudad que desea buscar");

		for (String clave : mapaPaises.keySet()) {
			if (mapaPaises.containsValue(ciudad)) {
				JOptionPane.showMessageDialog(null, "La ciudad " + ciudad + " pertene a " + clave);
			}
		}
	}
}